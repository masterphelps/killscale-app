/** @type {import('next').NextConfig} */
const nextConfig = {
  // Enable if you need static export
  // output: 'export',
}

module.exports = nextConfig
